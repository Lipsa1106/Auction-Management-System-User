﻿namespace HiTech.Controllers
{
    internal class sampleDBEntites
    {
        public sampleDBEntites()
        {
        }
    }
}